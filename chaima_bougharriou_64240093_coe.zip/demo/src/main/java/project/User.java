package project;
public class User {

    // username of the user
    private final String username;

    // password of the user
    private final String password;

    // constructor to create a user
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // return username
    public String getUsername() {
        return username;
    }

    // return password
    public String getPassword() {
        return password;
    }
}
