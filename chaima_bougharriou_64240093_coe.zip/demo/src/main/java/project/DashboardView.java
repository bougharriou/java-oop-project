package project;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DashboardView {

    public static void show(Stage stage, String username) {

        // Title
        Label title = new Label("Dashboard");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Welcome message
        Label welcome = new Label("Welcome " + username);

        // Buttons
        Button roomsButton = new Button("Rooms");
        roomsButton.setPrefWidth(180);
        roomsButton.setOnAction(e -> RoomsView.show(stage, username));

        Button customersButton = new Button("Customers");
        customersButton.setPrefWidth(180);
        customersButton.setOnAction(e -> CustomersView.show(stage, username));

        Button reservationsButton = new Button("Reservations");
        reservationsButton.setPrefWidth(180);
        reservationsButton.setOnAction(e -> ReservationsView.show(stage, username));

        Button logoutButton = new Button("Logout");
        logoutButton.setPrefWidth(180);
        logoutButton.setOnAction(e -> Main.showLogin(stage));

        // Layout
        VBox root = new VBox(12);
        root.setPadding(new Insets(25));
        root.getChildren().addAll(
                title,
                welcome,
                roomsButton,
                customersButton,
                reservationsButton,
                logoutButton
        );

        // Scene
        Scene scene = new Scene(root, 360, 300);
        stage.setScene(scene);
        stage.setTitle("Dashboard");
        stage.show();
    }
}
