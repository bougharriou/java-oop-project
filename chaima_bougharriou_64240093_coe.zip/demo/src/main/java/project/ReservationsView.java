package project;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ReservationsView {

    public static void show(Stage stage, String username) {

        Label title = new Label("Reservations");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label userLabel = new Label("Welcome " + username);

        TextField customerField = new TextField();
        customerField.setPromptText("Customer name");

        TextField roomField = new TextField();
        roomField.setPromptText("Room number (1-25)");

        Button confirmButton = new Button("Confirm");
        confirmButton.setDefaultButton(true);

        Label result = new Label();

        confirmButton.setOnAction(e -> {
            String customer = customerField.getText().trim();
            String roomText = roomField.getText().trim();

            if (customer.isEmpty() || roomText.isEmpty()) {
                result.setText("Please fill all fields");
                return;
            }

            int roomNumber;
            try {
                roomNumber = Integer.parseInt(roomText);
            } catch (NumberFormatException ex) {
                result.setText("Room number must be a number (1-25)");
                return;
            }

            if (roomNumber < 1 || roomNumber > 25) {
                result.setText("Room number must be between 1 and 25");
                return;
            }

            boolean ok = HotelData.reserveRoom(roomNumber, customer);
            if (!ok) {
                result.setText("Room " + roomNumber + " is already reserved");
                return;
            }

            result.setText("Reserved Room " + roomNumber + " for " + customer);
            customerField.clear();
            roomField.clear();
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DashboardView.show(stage, username));

        VBox root = new VBox(12, title, userLabel, customerField, roomField, confirmButton, result, backButton);
        root.setPadding(new Insets(20));

        stage.setScene(new Scene(root, 420, 320));
        stage.setTitle("Reservations");
        stage.show();
    }
}
