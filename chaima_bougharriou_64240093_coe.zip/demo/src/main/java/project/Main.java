package project;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    // simple auth service
    private static final AuthService authService = new AuthService();

    @Override
    public void start(Stage stage) {
        showLogin(stage);
        stage.show();
    }

    // Login screen
    public static void showLogin(Stage stage) {

        Label title = new Label("Hotel Management System");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Label message = new Label();

        Button loginButton = new Button("Login");
        loginButton.setDefaultButton(true); // Enter key works

        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                message.setText("Please enter username and password");
                return;
            }

            if (authService.login(username, password)) {
                message.setText("");
                DashboardView.show(stage, username);
            } else {
                message.setText("Wrong username or password");
                passwordField.clear();
            }
        });

        VBox root = new VBox(10);
        root.setPadding(new Insets(25));
        root.getChildren().addAll(
                title,
                usernameField,
                passwordField,
                loginButton,
                message
        );

        Scene scene = new Scene(root, 360, 260);
        stage.setScene(scene);
        stage.setTitle("Login");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
