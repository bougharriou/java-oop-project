package project;


public class AuthService {
// simple login - accepts admin/admin or any user/password combo
// in a real app this would check a database
public boolean login(String username, String password) {
// hardcoded user for demo: admin / admin
    
return username.equals("admin") && password.equals("admin");
}

}