package project;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CustomersView {

    public static void show(Stage stage, String username) {

        Label title = new Label("Customers");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label welcome = new Label("Welcome " + username);

        // simple customers list
        Label c1 = new Label("1) Ahmed  - 0551234567");
        Label c2 = new Label("2) Sara   - 0559876543");
        Label c3 = new Label("3) Lina   - 0551112223");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DashboardView.show(stage, username));

        VBox root = new VBox(12);
        root.setPadding(new Insets(20));
        root.getChildren().addAll(title, welcome, c1, c2, c3, backButton);

        Scene scene = new Scene(root, 420, 260);
        stage.setScene(scene);
        stage.setTitle("Customers");
        stage.show();
    }
}
