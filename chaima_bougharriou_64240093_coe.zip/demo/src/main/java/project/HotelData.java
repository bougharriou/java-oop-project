package project;

public class HotelData {


    private static final boolean[] reserved = new boolean[26];
    private static final String[] customerName = new String[26];

    public static boolean isReserved(int roomNumber) {
        if (roomNumber < 1 || roomNumber > 25) return true;
        return reserved[roomNumber];
    }

    public static String getCustomer(int roomNumber) {
        if (roomNumber < 1 || roomNumber > 25) return "";
        return customerName[roomNumber] == null ? "" : customerName[roomNumber];
    }

    public static boolean reserveRoom(int roomNumber, String customer) {
        if (roomNumber < 1 || roomNumber > 25) return false;
        if (reserved[roomNumber]) return false;

        reserved[roomNumber] = true;
        customerName[roomNumber] = customer;
        return true;
    }
}
