package project;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RoomsView {

    public static void show(Stage stage, String username) {

        // Top title + legend
        Label title = new Label("Room Overview");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Label legend = new Label("Legend:  Available = Green   |   Reserved = Gray");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DashboardView.show(stage, username));

        VBox topBox = new VBox(8, backButton, title, legend);
        topBox.setPadding(new Insets(15));

        // Rooms grid (5x5 = 25 rooms)
        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(15));

        // Right side details
        Label detailsTitle = new Label("Room Details");
        detailsTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label roomInfo = new Label("Room: -");
        Label statusInfo = new Label("Status: -");
        Label customerInfo = new Label("Customer: -");

        VBox detailsBox = new VBox(10, detailsTitle, roomInfo, statusInfo, customerInfo);
        detailsBox.setPadding(new Insets(15));
        detailsBox.setPrefWidth(220);

        int roomNumber = 1;
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {

                int currentRoom = roomNumber;

                Button roomBtn = new Button();
                roomBtn.setPrefSize(130, 75);
                roomBtn.setStyle(styleForRoom(currentRoom));

                updateRoomButtonText(roomBtn, currentRoom);

                roomBtn.setOnAction(e -> {
                    roomInfo.setText("Room: " + currentRoom);

                    boolean reserved = HotelData.isReserved(currentRoom);
                    statusInfo.setText("Status: " + (reserved ? "Reserved" : "Available"));

                    String customer = HotelData.getCustomer(currentRoom);
                    customerInfo.setText("Customer: " + (customer.isEmpty() ? "-" : customer));
                });

                grid.add(roomBtn, col, row);
                roomNumber++;
            }
        }

        BorderPane root = new BorderPane();
        root.setTop(topBox);
        root.setCenter(grid);
        root.setRight(detailsBox);
        root.setPadding(new Insets(10));

        stage.setScene(new Scene(root, 980, 520));
        stage.setTitle("Rooms");
        stage.show();
    }

    private static void updateRoomButtonText(Button btn, int roomNumber) {
        boolean reserved = HotelData.isReserved(roomNumber);
        String status = reserved ? "Reserved" : "Available";
        btn.setText("Room " + roomNumber + "\n" + status);
    }

    private static String styleForRoom(int roomNumber) {
        boolean reserved = HotelData.isReserved(roomNumber);

        if (reserved) {
            return "-fx-background-color: #bdbdbd; -fx-text-fill: black; -fx-font-weight: bold;";
        } else {
            return "-fx-background-color: #7CDA7C; -fx-text-fill: black; -fx-font-weight: bold;";
        }
    }
}
