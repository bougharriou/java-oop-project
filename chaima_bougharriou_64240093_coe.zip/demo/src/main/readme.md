# Hotel Management System (Java) — Project README

## Overview
This project is a **Java Hotel Management desktop application** developed as part of an OOP/Java coursework project.  
It provides a simple interface to manage hotel-related operations (navigation dashboard + main screens), with working UI flows and basic management features depending on the implemented views.

This README explains:
- The **state we reached** in development
- What is **working**
- What is **not fully implemented yet**
- Exactly **how to run** the application correctly (important for grading)

---

## Current State of the Project

###  What is working
- **Application launches successfully** from the project entry point.
- **Main navigation / Dashboard** UI is implemented.
- **Screens (Views)** are accessible through buttons (example: Employees / Customers / etc. depending on your project structure).
- **Scene switching / Navigation** works using JavaFX stages/scenes (opening different views from buttons).
- **Basic UI layout and styling** (the app structure matches the required design direction for the project).

> Note: The project was structured to focus on a clean UI workflow first (dashboard → pages), and then connect features progressively.

---

###  Partially working / In progress
Depending on the version submitted, some sections may be present but not fully connected to real data yet:
- Some pages may display UI but not persist data (no database/file saving).
- Some “Add / Edit / Delete” operations may exist as UI only (or may be implemented only for specific modules).
- Input validation may be minimal or still in progress.

---

###  Not implemented (or planned improvements)
- Full persistence (Database or file storage) if not added yet.
- Advanced reporting/export features (optional).
- Full role-based login / authentication (if not completed).
- Complete CRUD for every entity if not completed.

---

## Technologies Used
- **Java**
- **JavaFX** (UI)
- (Optional depending on your project) CSS for styling

---

## Project Structure (Typical)
Your project may include folders like:
- `src/` → Java source code
- `resources/` → FXML / images / CSS (if used)
- Views files (ex: `DashboardView`, `EmployeesView`, `CustomersView`, etc.)

The entry point to start the app is:

 **`Launcher.java`**

---

## How to Run the Application (IMPORTANT)

### Correct way (recommended for professor / grading)
**Do NOT run only a single `.java` file manually.**  
You must **run the entire project** so JavaFX resources, package structure, and dependencies are loaded correctly.

#### Steps (IntelliJ IDEA)
1. Open IntelliJ IDEA
2. Click **File → Open**
3. Select the **project folder** (the folder that contains `src/`, `pom.xml` or build files if any, and your packages)
4. Wait for IntelliJ to index the project
5. In the Project panel, navigate to:

   `src/.../Launcher.java`

6. Right click **Launcher.java**
7. Click **Run 'Launcher.main()'**

 The app should open starting from the main dashboard/home screen.

---

### If it says JavaFX runtime components are missing
Make sure JavaFX is configured:
- Project SDK set to the correct Java version
- VM options include JavaFX module path (only if your setup requires it)






## Authors
- (Chaima Bougharriou)
- 64240093

---

## License
This project was created for educational purposes (coursework).
